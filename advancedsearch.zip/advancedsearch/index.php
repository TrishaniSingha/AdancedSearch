<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Flight Search Panel</title>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
      <link rel="stylesheet" href="css/style.css">
   </head>
   <body>
      <?php include_once "dbconfig.php"; ?>
      <div class="container-fluid">
         <br>
         <h1>Flight Search Panel</h1>
         <input class="form-control" id="myInput" type="text" placeholder="Search..">
         <hr>
         <div class="row" >
            <div class="col-md-2">
               <div class="form-group">
                  <label for="CompanyName">Company Name</label>
                  <select  id="CompanyName"  onchange="getCompany()" class="form-control">
                  <?php echo  $companyName; ?>
                  </select>
               </div>
               <div class="form-group">
                  <label for="SourcePlace">From</label>
                  <select id="SourcePlace" onchange="getSource()" class="form-control">
                  <?php echo $originPlace; ?>
                  </select>
               </div>
               <div class="form-group">
                  <label for="DestinationPlace">To</label>
                  <select id="DestinationPlace"  onchange="getDestination()" class="form-control">
                  <?php echo $destination; ?>
                  </select>
               </div>
            </div>
            <div class="col-md-10">
               <table id="DataTable"  class="table table-borderless">
                  <?php
                     if (mysqli_num_rows($result) > 0) {
                        while($row = mysqli_fetch_assoc($result)) {
                           echo "<tr>";
                           echo "<td>".$row['flight_id']. "</td>";
                           echo "<td>".$row['flight_number']."</td>";
                           echo "<td id='company'>".$row['company_name']."</td>";
                           echo "<td>".$row['origin_place']. "</td>";
                           echo "<td>".$row['destination_place']."</td>";
                           echo "<td>".$row['time_start']."</td>";
                           echo "<td>".$row['time_end']. "</td>";
                           echo "</tr>";
                        }
                     } 
                     else 
                     {
                        echo "0 results";
                     }
                        mysqli_close($mysqli);
                     ?>
               </table>
            </div>
         </div>
      </div>
      <!-- jQuery library -->
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <script>
         $(document).ready(function(){
           $("#myInput").on("keyup", function() {
             var value = $(this).val().toLowerCase();
             $("#DataTable tr").filter(function() {
               $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
             });
           });
         });
      </script>
      <script src="js/FilterData.js"></script>
   </body>
</html>