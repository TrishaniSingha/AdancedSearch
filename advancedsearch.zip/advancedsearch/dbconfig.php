<?php
$mysqli = new mysqli("localhost","root","","flight_db");
$companyName = null;
$originPlace = null;
$destination = null;
if ($mysqli -> connect_errno) {
  echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
  exit();
}
$sql = "SELECT * FROM `flight_details`";
$result = mysqli_query($mysqli, $sql);
$sql2 = "SELECT distinct `origin_place` FROM `flight_details`";
$result2 = mysqli_query($mysqli, $sql2);
$sql3 = "SELECT distinct `destination_place` FROM `flight_details`";
$result3 = mysqli_query($mysqli, $sql3);
$sql4 = "SELECT distinct `company_name` FROM `flight_details`";
$result4 = mysqli_query($mysqli, $sql4);

if (mysqli_num_rows($result4) > 0) {
    while($row4 = mysqli_fetch_assoc($result4)) {
       $companyName .="<option>".$row4['company_name']."</option>";
    }
  } 
  if (mysqli_num_rows($result2) > 0) {
    while($row2 = mysqli_fetch_assoc($result2)) {
       $originPlace .=  "<option>".$row2['origin_place']."</option>";
    }
  } 

  if (mysqli_num_rows($result3) > 0) {
    while($row3 = mysqli_fetch_assoc($result3)) {
       $destination .= "<option>".$row3['destination_place']."</option>";
    }
  }
    
?>

